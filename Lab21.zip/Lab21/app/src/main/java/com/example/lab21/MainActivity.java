package com.example.lab21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    int x=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Button gameButton = new Button(this);
        gameButton.setText("You have pressed the button "+(int)x + " times");
        gameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                x=x+1;
                gameButton.setText("You have pressed the button "+(int)x + " times");
            }
        });
        setContentView(gameButton);

    }
}
